package com.sb1.repo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Repository extends JpaRepository<Users, String> {

}
