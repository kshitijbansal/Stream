package com.sb1.repo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Users {
	
	@Id
	private String userID;
	private String userName;
	private String userAddress;
	
	public Users() {

	}
	
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	
	public Users(String userID, String userName, String userAddress) {
		super();
		this.userID = userID;
		this.userName = userName;
		this.userAddress = userAddress;
	}

}
