package com.sb2.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@Autowired
	private Repository repository;
	
	@GetMapping(path = "empGet")
	public List<Employee> create() {
	    return repository.findAll();
	    }
	
	@PostMapping(path = "employee")
	public Employee create(@RequestBody Employee newEmp) {
	    repository.save(newEmp);
	    return newEmp;
	    }

}
