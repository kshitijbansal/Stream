package com.sb2.repo;

import org.springframework.data.jpa.repository.JpaRepository;


public interface Repository extends JpaRepository<Employee, String> {

}
